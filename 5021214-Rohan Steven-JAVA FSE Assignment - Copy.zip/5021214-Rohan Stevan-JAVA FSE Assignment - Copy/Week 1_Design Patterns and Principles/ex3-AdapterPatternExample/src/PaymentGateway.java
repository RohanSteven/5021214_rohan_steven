public class PaymentGateway {
    public static void main(String[] args) {
        PaymentProcessor paymentProcessor;

        // Use PayPal Payment
        paymentProcessor = new PayPalPaymentAdapter(new PayPalPayment());
        paymentProcessor.processPayment(100.0);

        // Use Stripe Payment
        paymentProcessor = new StripePaymentAdapter(new StripePayment());
        paymentProcessor.processPayment(200.0);


    }
}
