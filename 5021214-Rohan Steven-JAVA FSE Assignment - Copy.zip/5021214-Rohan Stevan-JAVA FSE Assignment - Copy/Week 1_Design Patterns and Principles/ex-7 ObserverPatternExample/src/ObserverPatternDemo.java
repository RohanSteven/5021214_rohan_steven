public class ObserverPatternDemo {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer investor1 = new StockObserver("Investor 1");
        Observer investor2 = new StockObserver("Investor 2");
        Observer investor3 = new StockObserver("Investor 3");

        stockMarket.register(investor1);
        stockMarket.register(investor2);
        stockMarket.register(investor3);

        stockMarket.setStockValue("AAPL", 150.0);
        stockMarket.setStockValue("GOOGL", 2800.0);
        stockMarket.setStockValue("TSLA", 700.0);

        stockMarket.deregister(investor2);

        stockMarket.setStockValue("AMZN", 3500.0);
    }
}
