public class RealImage implements Image {
    private String  url;
    public RealImage(String url) {
        this.url = url;
        loadimage(url);
    }
    public void loadimage(String url) {
        System.out.println("Loading image: " + url);
    }
    @Override
    public void display() {
        System.out.println("Displaying image: " + url);
    }
}
