public class ProxyPatternTest{
    public static void main(String[] args) {
        Image image1 = new ProxyImage("https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.worldatlas.com%2Fislands%2Fjava-island.html&psig=AOvVaw3IePAsK1aQWpouAPtonlnV&ust=1722413575672000&source=images&cd=vfe&opi=89978449&ved=2ahUKEwiZ3vjbqM6HAxXFUWwGHQPaI_kQjRx6BAgAEBU");
        Image image2 = new ProxyImage("https://www.google.com/imgres?q=%20island&imgurl=https%3A%2F%2Fimg.etimg.com%2Fthumb%2Fmsid-101094480%2Cwidth-640%2Cheight-480%2Cimgsize-172516%2Cresizemode-4%2Fcocoa-island-maldives.jpg&imgrefurl=https%3A%2F%2Fm.economictimes.com%2Findustry%2Fservices%2Ftravel%2Fthese-are-the-worlds-5-most-expensive-islands-to-visit-in-2023%2Fcocoa-island-maldives%2Fslideshow%2F101094480.cms&docid=5x9tAhDwEouJZM&tbnid=cH-kch6nd_O8WM&vet=12ahUKEwjPv-mGqc6HAxU_yjgGHcxzO_MQM3oFCIABEAA..i&w=640&h=480&hcb=2&ved=2ahUKEwjPv-mGqc6HAxU_yjgGHcxzO_MQM3oFCIABEAA");

        // Image will be loaded from server and displayed
        image1.display();
        System.out.println();

        image2.display();
        System.out.println();

        // Image will not be loaded from server again, just displayed
        image1.display();
        image2.display();


    }
}
