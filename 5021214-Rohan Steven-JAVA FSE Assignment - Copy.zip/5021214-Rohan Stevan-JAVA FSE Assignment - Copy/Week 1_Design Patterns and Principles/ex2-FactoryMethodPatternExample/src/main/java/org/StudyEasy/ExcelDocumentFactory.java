package org.StudyEasy;

public class ExcelDocumentFactory extends DocumentFactory {
    @Override
    protected document create() {
        return new ExcelDocument();
    }
}
