package org.StudyEasy;

public abstract class DocumentFactory {
    public void createDocument() {
        document document = create();
        document.open();
        document.read();
        document.write("Sample content");
        document.close();
    }

    protected abstract document create();
}
