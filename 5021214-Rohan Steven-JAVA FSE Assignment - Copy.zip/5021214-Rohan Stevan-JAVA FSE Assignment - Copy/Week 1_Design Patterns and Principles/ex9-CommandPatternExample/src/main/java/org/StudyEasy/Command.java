package org.StudyEasy;

public interface Command {
    void execute();
}
