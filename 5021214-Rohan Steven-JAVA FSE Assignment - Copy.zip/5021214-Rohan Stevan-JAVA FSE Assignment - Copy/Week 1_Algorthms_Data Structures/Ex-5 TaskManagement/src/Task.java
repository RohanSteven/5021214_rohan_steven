public class Task {
    private int taskid;
    private String name;
    private String status;

    public Task(int taskid, String name, String status) {
        this.taskid = taskid;
        this.name = name;
        this.status = status;

    }

    // Getters
    public int getTaskid() {
        return taskid;
    }



    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + taskid +
                ", Name='" + name+ '\'' +
                ", Status=" + status +

                '}';
    }
}

