
public interface TaskManager {
    void addTask(Task task);
    void deleteTask(int id);
    Task searchTask(int id);
    void traverseTasks();
}
