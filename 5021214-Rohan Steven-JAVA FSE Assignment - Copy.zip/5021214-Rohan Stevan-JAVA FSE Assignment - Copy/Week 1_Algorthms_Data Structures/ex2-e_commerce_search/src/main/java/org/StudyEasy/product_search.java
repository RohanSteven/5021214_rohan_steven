package org.StudyEasy;

import java.util.Scanner;

public class product_search {
    public static void main(String[] args) {
        inventory inventory = new inventory();
        Scanner sc = new Scanner(System.in);

        // Adding items
        inventory.addItem(new product(1, "apple", "fruits"));
        inventory.addItem(new product(2, "pen", "stationaries"));

        // Display inventory
        System.out.println("Initial Inventory:");
        inventory.displayInventory();

        // Search for a product
        System.out.println("Enter the product id:");
        int searchVal = sc.nextInt();
        product searchProd = linearSearch.linearSearch(inventory.getProductList(), searchVal);

        if (searchProd != null) {
            System.out.println("linear search Product found: " + searchProd);
        } else {
            System.out.println("Product with ID " + searchVal + " not found.");
        }
        product searchProd1=BinarySearch.binarySearch(inventory.getSortedProductList(),searchVal,inventory.getSortedProductList().size());
        if (searchProd1 != null) {
            System.out.println("Binary Search Product found: " + searchProd1);
        } else {
            System.out.println("Product with ID " + searchVal + " not found.");
        }
        // Display inventory after update
        System.out.println("\nInventory after searching:");
        inventory.displayInventory();

        // Remove an item
        inventory.removeItem("apple");

        // Display inventory after removing an item
        System.out.println("\nInventory after removing Apple:");
        inventory.displayInventory();

        sc.close();
    }
}
