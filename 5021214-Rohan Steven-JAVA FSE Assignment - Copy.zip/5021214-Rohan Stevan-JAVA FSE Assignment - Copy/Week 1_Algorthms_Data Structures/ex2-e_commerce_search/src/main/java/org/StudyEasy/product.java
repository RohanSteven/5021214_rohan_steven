package org.StudyEasy;

public class product {
    public int productID;
    public String productname;
    private String category;

    public product(int productID,String name, String category) {
        this.productID=productID;
        this.productname = name;
        this.category = category;
    }

    // Getters and setters
    public String getName() {
        return productname;
    }

    public String getcategory() {
        return category;
    }

    public int getProductID() {
        return productID;
    }


    @Override
    public String toString() {
        return "Item{" +
                "id="+ productID+
                ", name='" + productname + '\'' +
                ", category=" + category +
                '}';
    }
}