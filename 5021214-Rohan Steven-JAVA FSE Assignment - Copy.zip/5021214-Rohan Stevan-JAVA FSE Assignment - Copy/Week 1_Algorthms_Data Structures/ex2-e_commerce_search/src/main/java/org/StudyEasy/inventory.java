package org.StudyEasy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class inventory {
    private List<product> productList;

    public inventory() {
        this.productList = new ArrayList<>();
    }

    public void addItem(product product) {
        productList.add(product);
    }

    public void removeItem(String productName) {
        productList.removeIf(product -> product.getName().equalsIgnoreCase(productName));
    }

    public void displayInventory() {
        for (product product : productList) {
            System.out.println(product);
        }
    }

    public List<product> getProductList() {
        return productList;
    }
    public List<product> getSortedProductList() {
        List<product> sortedProductList = new ArrayList<>(productList);
        Collections.sort(sortedProductList, Comparator.comparingInt(product::getProductID));
        return sortedProductList;
    }

}
