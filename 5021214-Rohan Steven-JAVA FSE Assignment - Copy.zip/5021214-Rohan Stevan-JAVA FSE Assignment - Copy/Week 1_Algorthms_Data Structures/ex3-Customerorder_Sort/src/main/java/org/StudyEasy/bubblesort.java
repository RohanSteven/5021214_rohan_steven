package org.StudyEasy;

import java.util.ArrayList;
import java.util.*;

public class bubblesort {
    public ArrayList<order> bubblesort(ArrayList<order> arr)
    {
        int n = arr.size();
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++){
                if (arr.get(j).getTotalprice() > arr.get(j+1).getTotalprice()) {
                    // swap temp and arr[i]
                    Collections.swap(arr, j,j+1);

                }
    }

        return arr;
    }
}

