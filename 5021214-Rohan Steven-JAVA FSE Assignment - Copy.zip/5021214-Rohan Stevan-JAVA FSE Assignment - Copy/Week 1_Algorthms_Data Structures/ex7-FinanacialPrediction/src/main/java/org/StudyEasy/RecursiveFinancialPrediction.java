package org.StudyEasy;

public class RecursiveFinancialPrediction {

    public static void main(String[] args) {
        double[] pastData = {100, 102, 105, 107, 110};
        int steps = 5; // Number of future steps to predict

        for (int i = 1; i <= steps; i++) {
            double predictedValue = predictFutureValue(pastData, i);
            System.out.println("Predicted value at step " + i + ": " + predictedValue);
        }
    }

    public static double predictFutureValue(double[] pastData, int step) {
        if (step == 1) {
            return simpleAverage(pastData);
        } else {
            double[] newPastData = new double[pastData.length + 1];
            System.arraycopy(pastData, 0, newPastData, 0, pastData.length);
            newPastData[pastData.length] = predictFutureValue(pastData, step - 1);
            return simpleAverage(newPastData);
        }
    }

    public static double simpleAverage(double[] data) {
        double sum = 0;
        for (double value : data) {
            sum += value;
        }
        return sum / data.length;
    }
}
