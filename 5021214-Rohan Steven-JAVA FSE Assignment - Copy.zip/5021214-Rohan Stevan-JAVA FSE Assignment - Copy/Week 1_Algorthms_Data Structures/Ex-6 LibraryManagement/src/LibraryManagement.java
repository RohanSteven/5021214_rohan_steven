public class LibraryManagement {
    public static void main(String[] args) {
        Book[] books = {
                new Book("The Catcher in the Rye", "J.D. Salinger", 32),
                new Book("To Kill a Mockingbird", "Harper Lee", 60),
                new Book("1984", "George Orwell", 132),
                new Book("The Great Gatsby", "F. Scott Fitzgerald", 195),
                new Book("Moby-Dick", "Herman Melville", 851)
        };

        // Test Linear Search
        Book foundBook = BookSearch.linearSearch(books, "1984");
        System.out.println("Linear Search Result: " + (foundBook != null ? foundBook : "Book not found"));

        // Test Binary Search
        foundBook = BookSearch.binarySearch(books, "The Great Gatsby");
        System.out.println("Binary Search Result: " + (foundBook != null ? foundBook : "Book not found"));
    }
}