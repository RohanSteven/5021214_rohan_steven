public interface EmployeeManager {
    void addEmployee(Employee employee);
    void deleteEmployee(int id);
    Employee searchEmployee(int id);
    void traverseEmployees();
}
